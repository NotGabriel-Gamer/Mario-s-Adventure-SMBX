Mario's Adventure
--- Made By Gabriel_Gamer ---
--- Youtube channel: https://www.youtube.com/channel/UCLDkepn2HNsvwgsm5f_HnaA ---
--- Original Post: https://www.supermariobrosx.org/forums/viewtopic.php?f=90&t=26977 ---

--- Graphics ---
>Here are some observations about the Mario's Adventure project:
>The texture pack "Valtteri's Graphics Pack 1.0.1" was used.
>The texture pack "Squishy Rex's CGFX Pack V1.8" was used
>Other graphics of the standard battle levels, and the "Princess Cliche" episode were also used

--- Bugs and Glitches ---
>Maybe some bosses don't need to be defeated, as it seems, some of them have buggy layers
>In that same matter of layers, some sound effects can play on occasions when they were not to be properly reproduced, causing strange situations

--- IMPORTANT ---
>Now the episode will be translated to English, the current demo will not be updated btw, this was a serious mistake I made.
>If you are going to play this, consider giving feedback, so that I can adjust / improve some things,i accept any feedback, both positive and negative, mainly the negative ones, as they can improve in some aspects that I didn't do very well, such as level design
